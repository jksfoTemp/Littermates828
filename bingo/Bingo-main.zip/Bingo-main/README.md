# Bingo
An Excel based bingo card generator for holiday or event entertainment. Office 2010+, ported for 64 bit. 
Just some space.

And another edit. 
Just fecking save 2
Just fecking save 3
Just fecking save 4 stop prompting me for a dirty save. Actually just let me save the damn file and then commit the save without having to select fucking 'discard' and then the damn changes are commited anyway. 
